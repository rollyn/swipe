import { Box, Typography } from '@mui/material';

const Footer = () => {
  return (
    <Box
      component="footer"
      sx={{
        width: '100vw',
        padding: '20px',
        backgroundColor: '#f5f5f5',
        position: 'fixed',
        bottom: 0,
        left: 0,
        textAlign: 'center',
        boxShadow: '0 -2px 4px rgba(0,0,0,0.1)',
        zIndex: 1000
      }}
    >
      <Typography variant="body2" color="text.secondary">
        {new Date().getFullYear()} SkillSwipe. All rights reserved.
      </Typography>
    </Box>
  );
};

export default Footer;
