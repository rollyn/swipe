import React from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  useTheme,
  Avatar
} from '@mui/material';
import {
  Person as PersonIcon,
  Favorite as FavoriteIcon,
  ExitToApp as LogoutIcon,
  SwapHoriz as SwipeIcon
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const Navbar = () => {
  const theme = useTheme();
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Don't show navbar on login and register pages
  if (['/login', '/register'].includes(location.pathname)) {
    return null;
  }

  return (
    <AppBar 
      position="fixed" 
      sx={{ 
        width: '100vw',
        backgroundColor: '#1976d2',
        color: 'white',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        left: 0
      }}
    >
      <Toolbar sx={{ justifyContent: 'space-between' }}>
        <Typography
          variant="h6"
          component={Link}
          to="/swipe"
          sx={{
            textDecoration: 'none',
            color: 'inherit',
            fontWeight: 'bold',
            cursor: 'pointer'
          }}
        >
          SkillSwipe
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {user && (
            <Box sx={{ display: 'flex', alignItems: 'center', mr: 2 }}>
              <Avatar 
                src={user.profilePicture} 
                sx={{ width: 32, height: 32, mr: 1 }}
              >
                {user.username?.[0]?.toUpperCase()}
              </Avatar>
              <Typography sx={{ color: 'white', mr: 2 }}>
                {user.username}
              </Typography>
            </Box>
          )}
          
          <IconButton
            component={Link}
            to="/swipe"
            sx={{ color: 'white', '&:hover': { color: '#bbdefb' } }}
          >
            <SwipeIcon />
          </IconButton>
          
          <IconButton
            component={Link}
            to="/matches"
            sx={{ color: 'white', '&:hover': { color: '#bbdefb' } }}
          >
            <FavoriteIcon />
          </IconButton>
          
          <IconButton
            component={Link}
            to="/profile/edit"
            sx={{ color: 'white', '&:hover': { color: '#bbdefb' } }}
          >
            <PersonIcon />
          </IconButton>
          
          <IconButton
            onClick={handleLogout}
            sx={{ color: 'white', '&:hover': { color: '#bbdefb' } }}
          >
            <LogoutIcon />
          </IconButton>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
