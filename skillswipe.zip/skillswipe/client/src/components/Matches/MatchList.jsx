import React, { useState, useEffect, useRef } from 'react';
import {
  Container,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Typography,
  Paper,
  Box,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  IconButton
} from '@mui/material';
import { Message as MessageIcon, Send as SendIcon, Close as CloseIcon } from '@mui/icons-material';
import axios from 'axios';
import { io } from 'socket.io-client';

const MatchList = () => {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [socket, setSocket] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('No token found');
      return;
    }

    // Initialize socket connection with auth token
    const newSocket = io('http://localhost:5000', {
      auth: {
        token: token
      },
      transports: ['websocket', 'polling'],
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000
    });

    newSocket.on('connect', () => {
      console.log('Socket connected successfully');
      fetchMatches();
    });

    newSocket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      // Try to reconnect with new token if available
      const currentToken = localStorage.getItem('token');
      if (currentToken && currentToken !== token) {
        newSocket.auth = { token: currentToken };
        newSocket.connect();
      }
    });

    newSocket.on('error', (error) => {
      console.error('Socket error:', error);
    });

    setSocket(newSocket);

    return () => {
      if (newSocket) {
        newSocket.disconnect();
      }
    };
  }, []);

  useEffect(() => {
    if (!socket || !selectedMatch) return;

    const handleNewMessage = (message) => {
      console.log('Received message:', message);
      setMessages(prevMessages => {
        // Check if message already exists to prevent duplicates
        const exists = prevMessages.some(m => 
          m._id === message._id || 
          (m.content === message.content && 
           m.senderId === message.senderId && 
           Math.abs(m.timestamp - message.timestamp) < 1000) // Allow 1 second difference
        );
        if (!exists) {
          return [...prevMessages, message];
        }
        // If it was an optimistic message, replace it with the server version
        if (prevMessages.some(m => m._id?.startsWith('temp-'))) {
          return prevMessages.map(m => 
            (m.content === message.content && 
             m.senderId === message.senderId && 
             Math.abs(m.timestamp - message.timestamp) < 1000)
              ? message 
              : m
          );
        }
        return prevMessages;
      });
    };

    socket.on('receiveMessage', handleNewMessage);
    socket.on('messageError', (error) => {
      console.error('Message error:', error);
    });

    // Join chat room when match is selected
    socket.emit('joinChat', selectedMatch._id);
    console.log('Joined chat for match:', selectedMatch._id);

    return () => {
      socket.off('receiveMessage', handleNewMessage);
      socket.off('messageError');
    };
  }, [socket, selectedMatch]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const fetchMatches = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found');
        return;
      }

      const response = await axios.get('http://localhost:5000/api/matches', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('Matches fetched:', response.data);
      setMatches(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching matches:', error);
      setLoading(false);
    }
  };

  const handleMatchClick = async (match) => {
    setSelectedMatch(match);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:5000/api/messages/${match._id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessages(response.data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleChatClick = async (e, match) => {
    e.stopPropagation();
    setSelectedMatch(match);
    setChatOpen(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:5000/api/messages/${match._id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessages(response.data);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleCloseChat = () => {
    setChatOpen(false);
    setSelectedMatch(null);
    setMessages([]);
    setNewMessage('');
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedMatch) return;
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found');
        return;
      }

      if (!socket?.connected) {
        console.error('Socket not connected');
        return;
      }

      const decoded = JSON.parse(atob(token.split('.')[1]));
      const messageData = {
        senderId: decoded.userId,
        receiverId: selectedMatch._id,
        content: newMessage.trim(),
        timestamp: Date.now()
      };

      // Add optimistic message to UI
      const optimisticMessage = {
        ...messageData,
        _id: `temp-${Date.now()}` // Temporary ID for optimistic update
      };
      setMessages(prev => [...prev, optimisticMessage]);

      // Clear input immediately for better UX
      setNewMessage('');

      // Send through socket
      socket.emit('sendMessage', messageData);

    } catch (error) {
      console.error('Error in handleSendMessage:', error);
    }
  };

  if (loading) {
    return (
      <Container sx={{ mt: 4 }}>
        <Typography>Loading matches...</Typography>
      </Container>
    );
  }

  if (matches.length === 0) {
    return (
      <Container sx={{ mt: 4, textAlign: 'center' }}>
        <Typography variant="h6" color="text.secondary">
          No matches yet
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Keep swiping to find skill matches!
        </Typography>
      </Container>
    );
  }

  return (
    <Container sx={{ mt: 4 }}>
      <Typography variant="h5" sx={{ mb: 3 }}>
        Your Matches
      </Typography>
      <List>
        {matches.map((match) => (
          <Paper 
            key={match._id} 
            elevation={2} 
            sx={{ 
              mb: 2,
              '&:hover': {
                boxShadow: 3
              }
            }}
          >
            <ListItem
              alignItems="flex-start"
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 2,
                p: 2
              }}
            >
              <ListItemAvatar>
                <Avatar
                  src={match.profilePicture}
                  sx={{ 
                    width: 60, 
                    height: 60,
                    border: '2px solid #1976d2'
                  }}
                >
                  {match.username?.[0]?.toUpperCase()}
                </Avatar>
              </ListItemAvatar>
              <Box sx={{ flexGrow: 1 }}>
                <Typography variant="h6" gutterBottom>
                  {match.username}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {match.location}
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {match.skills?.map((skill, index) => (
                    <Chip
                      key={index}
                      label={`${skill.name} (${skill.level})`}
                      size="small"
                      sx={{
                        bgcolor: 'primary.main',
                        color: 'white'
                      }}
                    />
                  ))}
                </Box>
              </Box>
              <Button
                variant="contained"
                color="primary"
                startIcon={<MessageIcon />}
                onClick={(e) => handleChatClick(e, match)}
                sx={{
                  minWidth: '120px',
                  height: '45px',
                  borderRadius: '25px',
                  textTransform: 'none',
                  fontSize: '1rem',
                  fontWeight: 500,
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  '&:hover': {
                    boxShadow: '0 4px 6px rgba(0,0,0,0.15)',
                    bgcolor: 'primary.dark'
                  }
                }}
              >
                Chat Now
              </Button>
            </ListItem>
          </Paper>
        ))}
      </List>

      <Dialog
        open={chatOpen}
        onClose={handleCloseChat}
        fullWidth
        maxWidth="sm"
        PaperProps={{
          sx: {
            height: '80vh',
            maxHeight: '700px'
          }
        }}
      >
        <DialogTitle sx={{ 
          bgcolor: 'primary.main', 
          color: 'white',
          display: 'flex',
          alignItems: 'center',
          gap: 2
        }}>
          {selectedMatch && (
            <>
              <Avatar
                src={selectedMatch.profilePicture}
                sx={{ width: 40, height: 40 }}
              >
                {selectedMatch.username[0].toUpperCase()}
              </Avatar>
              <Typography variant="h6" sx={{ flexGrow: 1 }}>
                {selectedMatch.username}
              </Typography>
              <IconButton
                onClick={handleCloseChat}
                sx={{ color: 'white' }}
              >
                <CloseIcon />
              </IconButton>
            </>
          )}
        </DialogTitle>
        <DialogContent sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box 
            sx={{ 
              flexGrow: 1,
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
              mb: 2,
              maxHeight: 'calc(80vh - 200px)', // Adjust based on your needs
            }}
          >
            {messages.map((message, index) => {
              const token = localStorage.getItem('token');
              const userId = JSON.parse(atob(token.split('.')[1])).userId;
              const isCurrentUser = message.senderId === userId;

              return (
                <Box
                  key={index}
                  sx={{
                    alignSelf: isCurrentUser ? 'flex-end' : 'flex-start',
                    maxWidth: '70%'
                  }}
                >
                  <Paper
                    sx={{
                      p: 1,
                      backgroundColor: isCurrentUser ? 'primary.main' : 'grey.100',
                      color: isCurrentUser ? 'white' : 'text.primary'
                    }}
                  >
                    <Typography variant="body1">{message.content}</Typography>
                    <Typography variant="caption" sx={{ opacity: 0.7 }}>
                      {message.timestamp ? new Date(message.timestamp).toLocaleString() : 'Just now'}
                    </Typography>
                  </Paper>
                </Box>
              );
            })}
            {/* Add a div at the bottom for scrolling */}
            <div ref={messagesEndRef} style={{ height: 1 }} />
          </Box>
          <Box sx={{ display: 'flex', gap: 1, pt: 2, borderTop: '1px solid', borderColor: 'divider' }}>
            <TextField
              fullWidth
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              multiline
              maxRows={4}
              size="small"
            />
            <IconButton
              color="primary"
              onClick={handleSendMessage}
              disabled={!newMessage.trim()}
              sx={{ 
                bgcolor: 'primary.main',
                color: 'white',
                '&:hover': {
                  bgcolor: 'primary.dark'
                },
                '&.Mui-disabled': {
                  bgcolor: 'grey.300',
                  color: 'grey.500'
                }
              }}
            >
              <SendIcon />
            </IconButton>
          </Box>
        </DialogContent>
      </Dialog>
    </Container>
  );
};

export default MatchList;
