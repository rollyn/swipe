import React, { useState, useEffect } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Container,
  Paper,
  Chip,
  Stack,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Avatar,
  IconButton,
  Grid,
  Alert,
  FormGroup,
  FormControlLabel,
  Checkbox
} from '@mui/material';
import { PhotoCamera } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];

const EditProfile = () => {
  const [profile, setProfile] = useState({
    bio: '',
    location: '',
    skills: []
  });
  const [newSkill, setNewSkill] = useState({
    name: '',
    level: 'Beginner',
    willingToTeach: false,
    wantToLearn: false
  });
  const [profilePicture, setProfilePicture] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          navigate('/login');
          return;
        }

        const response = await axios.get('http://localhost:5000/api/users/profile', {
          headers: { Authorization: `Bearer ${token}` }
        });

        const userData = response.data;
        setProfile(prev => ({
          ...prev,
          username: userData.username || '',
          bio: userData.bio || '',
          location: userData.location || '',
          skills: userData.skills || []
        }));
        
        if (userData.profilePicture) {
          setPreviewUrl(`http://localhost:5000/api/users/profile-picture/${userData.profilePicture}`);
        }
      } catch (error) {
        console.error('Error loading profile:', error);
        setError('Failed to load profile');
      }
    };

    loadProfile();
  }, [navigate]);

  const handleProfilePictureChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }

      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result);
      };
      reader.readAsDataURL(file);

      // Upload the file
      const formData = new FormData();
      formData.append('profilePicture', file);

      const response = await axios.post(
        'http://localhost:5000/api/users/upload-profile-picture',
        formData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );

      // Update profile picture URL
      setProfile(prev => ({
        ...prev,
        profilePicture: response.data.filename
      }));
    } catch (error) {
      console.error('Error uploading profile picture:', error);
      setError('Failed to upload profile picture');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddSkill = () => {
    if (!newSkill.name || (!newSkill.willingToTeach && !newSkill.wantToLearn)) {
      setError('Please enter a skill name and select at least one preference (teach or learn)');
      return;
    }

    setProfile(prev => ({
      ...prev,
      skills: [...prev.skills, newSkill]
    }));

    setNewSkill({
      name: '',
      level: 'Beginner',
      willingToTeach: false,
      wantToLearn: false
    });
  };

  const handleRemoveSkill = (index) => {
    setProfile(prev => ({
      ...prev,
      skills: prev.skills.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    
    try {
      await axios.post('http://localhost:5000/api/users/profile', {
        bio: profile.bio,
        location: profile.location,
        skills: profile.skills
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // Clear all storage and navigate to login
      localStorage.clear();
      sessionStorage.clear();
      navigate('/login', { replace: true });
    } catch (error) {
      console.error('Profile update error:', error);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom align="center">
          Edit Profile
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {/* Profile Picture Section */}
        <Box sx={{ mb: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Avatar
            src={previewUrl}
            sx={{
              width: 150,
              height: 150,
              mb: 2,
              border: '3px solid #1976d2',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              borderRadius: '50%'
            }}
          />
          <input
            accept="image/*"
            style={{ display: 'none' }}
            id="profile-picture-input"
            type="file"
            onChange={handleProfilePictureChange}
          />
          <label htmlFor="profile-picture-input">
            <Button
              variant="outlined"
              component="span"
              startIcon={<PhotoCamera />}
            >
              Upload Photo
            </Button>
          </label>
        </Box>

        <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Username"
                name="username"
                value={profile.username}
                onChange={handleInputChange}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Bio"
                name="bio"
                multiline
                rows={4}
                value={profile.bio}
                onChange={handleInputChange}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Location"
                name="location"
                value={profile.location}
                onChange={handleInputChange}
              />
            </Grid>

            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Skills
              </Typography>

              <Box sx={{ mb: 3, p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Skill Name"
                      value={newSkill.name}
                      onChange={(e) => setNewSkill(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                      <InputLabel>Skill Level</InputLabel>
                      <Select
                        value={newSkill.level}
                        label="Skill Level"
                        onChange={(e) => setNewSkill(prev => ({ ...prev, level: e.target.value }))}
                      >
                        {skillLevels.map((level) => (
                          <MenuItem key={level} value={level}>
                            {level}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12}>
                    <FormGroup row>
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={newSkill.willingToTeach}
                            onChange={(e) => setNewSkill(prev => ({ ...prev, willingToTeach: e.target.checked }))}
                          />
                        }
                        label="Willing to Teach"
                      />
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={newSkill.wantToLearn}
                            onChange={(e) => setNewSkill(prev => ({ ...prev, wantToLearn: e.target.checked }))}
                          />
                        }
                        label="Want to Learn"
                      />
                    </FormGroup>
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      variant="contained"
                      onClick={handleAddSkill}
                    >
                      Add Skill
                    </Button>
                  </Grid>
                </Grid>
              </Box>

              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {profile.skills.map((skill, index) => (
                  <Chip
                    key={index}
                    label={`${skill.name} (${skill.level}) ${skill.willingToTeach ? '📚' : ''} ${skill.wantToLearn ? '📖' : ''}`}
                    onDelete={() => handleRemoveSkill(index)}
                    color={skill.willingToTeach ? "primary" : "secondary"}
                    sx={{ m: 0.5 }}
                  />
                ))}
              </Box>
            </Grid>

            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                fullWidth
                size="large"
                sx={{ mt: 2 }}
              >
                Save Changes
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
};

export default EditProfile;
