import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Box, CssBaseline } from '@mui/material';
import { AuthProvider } from './contexts/AuthContext';

// Components
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import EditProfile from './components/Profile/EditProfile';
import SwipePage from './components/Swipe/SwipePage';
import MatchList from './components/Matches/MatchList';
import Navbar from './components/Layout/Navbar';
import Footer from './components/Layout/Footer';
import PrivateRoute from './components/Auth/PrivateRoute';

const theme = createTheme({
  palette: {
    primary: {
      main: '#2196f3',
    },
    secondary: {
      main: '#f50057',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <AuthProvider>
          <CssBaseline />
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column', 
            minHeight: '100vh'
          }}>
            <Navbar />
            <Box sx={{ 
              flexGrow: 1, 
              mt: '64px', // Height of navbar
              mb: '60px', // Height of footer
              p: 3 
            }}>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route
                  path="/profile/edit"
                  element={
                    <PrivateRoute>
                      <EditProfile />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/swipe"
                  element={
                    <PrivateRoute>
                      <SwipePage />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/matches"
                  element={
                    <PrivateRoute>
                      <MatchList />
                    </PrivateRoute>
                  }
                />
                <Route path="/" element={<Navigate to="/swipe" />} />
              </Routes>
            </Box>
            <Footer />
          </Box>
        </AuthProvider>
        <ToastContainer position="bottom-right" />
      </Router>
    </ThemeProvider>
  );
}

export default App;
