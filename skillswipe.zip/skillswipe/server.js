const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const multer = require('multer');
const { GridFsStorage } = require('multer-gridfs-storage');
const Grid = require('gridfs-stream');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

// Route imports
const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const messageRoutes = require('./routes/messageRoutes');
const skillRoutes = require('./routes/skillRoutes');
const matchRoutes = require('./routes/matchRoutes');

dotenv.config();

const app = express();

// CORS configuration
const allowedOrigins = ['http://localhost:3000', 'http://localhost:5173'];
app.use(cors({
  origin: function(origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
    transports: ['websocket', 'polling']
  },
  allowEIO3: true
});

// Store connected users
const connectedUsers = new Map();

// Socket.IO connection handling
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    if (!token) {
      return next(new Error('Authentication token missing'));
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      if (!decoded || !decoded.userId) {
        return next(new Error('Invalid token'));
      }
      socket.userId = decoded.userId;
      next();
    } catch (jwtError) {
      console.error('JWT verification error:', jwtError);
      next(new Error('Invalid token'));
    }
  } catch (error) {
    console.error('Socket auth error:', error);
    next(new Error('Authentication failed'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.userId;
  console.log('User connected:', userId);
  
  // Store user's socket connection
  connectedUsers.set(userId, socket.id);

  socket.on('joinChat', (matchId) => {
    console.log(`User ${userId} joining chat with ${matchId}`);
    socket.join(`chat_${userId}_${matchId}`);
  });

  socket.on('sendMessage', async (data) => {
    try {
      console.log('Received message:', data);

      // Validate message data
      if (!data.content || !data.receiverId) {
        socket.emit('messageError', { error: 'Invalid message data' });
        return;
      }

      // Save message to database
      const Message = mongoose.model('Message');
      const newMessage = new Message({
        senderId: userId,
        receiverId: data.receiverId,
        content: data.content
      });

      const savedMessage = await newMessage.save();
      console.log('Message saved:', savedMessage);

      // Prepare message for sending
      const messageToSend = {
        _id: savedMessage._id,
        senderId: userId,
        receiverId: data.receiverId,
        content: data.content,
        timestamp: savedMessage.createdAt.getTime() // Use the timestamp from MongoDB
      };

      // Send to sender
      socket.emit('receiveMessage', messageToSend);

      // Send to receiver if online
      const receiverSocketId = connectedUsers.get(data.receiverId);
      if (receiverSocketId) {
        io.to(receiverSocketId).emit('receiveMessage', messageToSend);
      }

      console.log('Message sent successfully');
    } catch (error) {
      console.error('Error handling message:', error);
      socket.emit('messageError', { error: 'Failed to send message' });
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', userId);
    connectedUsers.delete(userId);
  });
});

// Middleware
app.use(express.json());

// MongoDB connection
const uri = "mongodb+srv://ethanjames09090909:H6NqeQcwzWFHG3Rf@skillswipe.skf8f.mongodb.net/?retryWrites=true&w=majority&appName=skillswipe";

// Create GridFS storage engine
const storage = new GridFsStorage({
  url: uri,
  options: { useNewUrlParser: true, useUnifiedTopology: true },
  file: (req, file) => {
    return {
      bucketName: 'uploads',
      filename: `${Date.now()}-${file.originalname}`
    };
  }
});

const upload = multer({ storage });

let gfs;
mongoose.connect(uri)
  .then(() => {
    console.log('Connected to MongoDB');
    gfs = Grid(mongoose.connection.db, mongoose.mongo);
    gfs.collection('uploads');
  })
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/users', userRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/skills', skillRoutes);
app.use('/api/matches', matchRoutes);

// File upload route
app.post('/api/upload', upload.single('profilePicture'), (req, res) => {
  if (req.file) {
    res.json({ fileId: req.file.id });
  } else {
    res.status(400).json({ message: 'No file uploaded' });
  }
});

// Get profile picture
app.get('/api/image/:fileId', async (req, res) => {
  try {
    const file = await gfs.files.findOne({ _id: new mongoose.Types.ObjectId(req.params.fileId) });
    if (!file) {
      return res.status(404).json({ message: 'File not found' });
    }

    const readStream = gfs.createReadStream(file.filename);
    readStream.pipe(res);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving file' });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
