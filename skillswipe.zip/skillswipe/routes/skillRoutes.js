const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// Add a skill to user profile
router.post('/add', auth, async (req, res) => {
  try {
    const userId = req.user.id; // From middleware
    const { name, level, yearsOfExperience, willingToTeach, wantToLearn } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.skills.push({
      name,
      level,
      yearsOfExperience,
      willingToTeach,
      wantToLearn
    });

    await user.save();
    res.json(user.skills);
  } catch (error) {
    console.error('Error adding skill:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update a skill
router.put('/:skillId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const skillId = req.params.skillId;
    const { name, level, yearsOfExperience, willingToTeach, wantToLearn } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const skill = user.skills.id(skillId);
    if (!skill) {
      return res.status(404).json({ message: 'Skill not found' });
    }

    skill.name = name || skill.name;
    skill.level = level || skill.level;
    skill.yearsOfExperience = yearsOfExperience || skill.yearsOfExperience;
    skill.willingToTeach = willingToTeach !== undefined ? willingToTeach : skill.willingToTeach;
    skill.wantToLearn = wantToLearn !== undefined ? wantToLearn : skill.wantToLearn;

    await user.save();
    res.json(skill);
  } catch (error) {
    console.error('Error updating skill:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete a skill
router.delete('/:skillId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const skillId = req.params.skillId;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.skills = user.skills.filter(skill => skill.id !== skillId);
    await user.save();
    
    res.json({ message: 'Skill removed' });
  } catch (error) {
    console.error('Error deleting skill:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all skills for a user
router.get('/', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user.skills);
  } catch (error) {
    console.error('Error getting skills:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get users by skill
router.get('/users/:skillName', async (req, res) => {
  try {
    const skillName = req.params.skillName;
    const users = await User.find({
      'skills.name': skillName
    }).select('-password');

    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
