const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// Get all matches for a user
router.get('/', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId)
      .populate('matches', '-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user.matches);
  } catch (error) {
    console.error('Error getting matches:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get match details
router.get('/:matchId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const matchId = req.params.matchId;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (!user.matches.includes(matchId)) {
      return res.status(403).json({ message: 'Not a match' });
    }

    const match = await User.findById(matchId).select('-password');
    if (!match) {
      return res.status(404).json({ message: 'Match not found' });
    }
    
    res.json(match);
  } catch (error) {
    console.error('Error getting match details:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Unmatch with a user
router.delete('/:matchId', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const matchId = req.params.matchId;

    const [user, match] = await Promise.all([
      User.findById(userId),
      User.findById(matchId)
    ]);

    if (!user || !match) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.matches.pull(matchId);
    match.matches.pull(userId);

    await Promise.all([user.save(), match.save()]);

    res.json({ message: 'Unmatched successfully' });
  } catch (error) {
    console.error('Error unmatching:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
